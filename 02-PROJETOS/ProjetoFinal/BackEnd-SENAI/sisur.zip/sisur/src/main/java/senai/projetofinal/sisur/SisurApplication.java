package senai.projetofinal.sisur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SisurApplication {

	public static void main(String[] args) {
		SpringApplication.run(SisurApplication.class, args);
	}

}
