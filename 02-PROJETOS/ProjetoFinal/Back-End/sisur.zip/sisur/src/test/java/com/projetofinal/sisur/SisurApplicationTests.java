package com.projetofinal.sisur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SisurApplicationTests {

	@Test
	void contextLoads() {
	}

}
