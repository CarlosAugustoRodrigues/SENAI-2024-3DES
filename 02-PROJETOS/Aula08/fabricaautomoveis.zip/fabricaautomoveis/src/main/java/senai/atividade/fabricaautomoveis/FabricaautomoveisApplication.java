package senai.atividade.fabricaautomoveis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FabricaautomoveisApplication {

	public static void main(String[] args) {
		SpringApplication.run(FabricaautomoveisApplication.class, args);
	}

}
