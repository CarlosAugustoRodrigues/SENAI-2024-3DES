package senai.atividade.fabricaautomoveis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FabricaautomoveisApplicationTests {

	@Test
	void contextLoads() {
	}

}
